$(function () {

  // Slideshow 1
  $("#slider1").responsiveSlides({
    speed: 3000,
	timeout: 8000,
  });

});